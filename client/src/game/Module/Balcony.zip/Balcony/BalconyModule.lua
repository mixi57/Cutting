--Author: mixi
--Date: 2016-05-28 22:24:15
--Abstract: BalconyModule
local M = class("BalconyModule", View)

M.RESOUR_INFO = {
    --[[{  
        "MainScene.csb", 
        {
            ["roomBtn"] = {
                ["varname"] = "_roomBtn",
                ["events"] = {
                    ["event"] = "touch",
                    ["method"] = "openModuleByName",
                    ["params"] = "ROOM"
                },
            },
        }
    }]]
}
local function addReleaseEvent(event, callback, params)
    if event.name == "ended" then
        callback(params)
    end
end

function M:openModuleByName(params, event)
    addReleaseEvent(
        event,
        function(moduleName)
            GameManager.openModule(ModuleConfig[moduleName])
        end,
        params
    )
end

function M:initView()
    self:show()
end

return M
