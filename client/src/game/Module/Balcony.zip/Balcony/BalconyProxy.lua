--Author: mixi
--Date: 2016-05-30 21:01:05
--Abstract: 
local P = class("BalconyProxy")

function P:ctor()
	-- self.proxy = self.getProxy().Room
end

return P