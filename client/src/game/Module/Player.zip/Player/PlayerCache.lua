--Author: mixi
--Date: 2016-05-28 23:13:18
--Abstract: RoomCache

local balconyCache = {
}
return balconyCache